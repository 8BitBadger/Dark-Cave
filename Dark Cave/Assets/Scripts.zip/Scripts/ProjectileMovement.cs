using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "PluggableAI/Actions/Long Range Attack")]
public class ProjectileMovement : MonoBehaviour
{
    private float maxSpeed = 25f;
    private float rotateSpeed = 5f;
    private float projectileLife = 5f; //How long the projectile will persist in the world
    private float spawnTime; //The time the projectile was spawned.
    private Rigidbody2D rb2d;
    private Transform target;
    private bool followTarget = false;

    public Transform Target
    {
        set { target = value; }
    }

    public float MaxSpeed
    {
        set { maxSpeed = value; }
    }

    public float RotateSpeed
    {
        set { rotateSpeed = value; }
    }

    public bool FollowTarget
    {
        set { followTarget = value; }
    }

    public float ProjectileLife
    {
        set { projectileLife = value; }
    }

    void Start()
    {
        spawnTime = Time.time;
        rb2d = GetComponent<Rigidbody2D>();

        //Sets the start rotation of the projectile, this is so that if its only a streight fire projectile it will shoot towards the target
        //if more adjustments are needed it will check the bool followtarget is true it will adjust the cource of the projectile each update.
        Vector2 dir = new Vector2(target.position.x, target.position.y) - rb2d.position;
        dir.Normalize();
        float rotateAmount = Vector3.Cross(dir, transform.up).z;
        rb2d.MoveRotation(rotateAmount);
    }

    void FixedUpdate()
    {
        if ((Time.time - spawnTime) > projectileLife)
        {
            Destroy(gameObject);
        }
        Vector2 dir = new Vector2(target.position.x, target.position.y) - rb2d.position;
        dir.Normalize();
        float rotateAmount = Vector3.Cross(dir, transform.up).z;

        if (followTarget)
        {
            rb2d.angularVelocity = -rotateAmount * rotateSpeed;
        }

        rb2d.velocity = transform.forward * maxSpeed;
    }
}