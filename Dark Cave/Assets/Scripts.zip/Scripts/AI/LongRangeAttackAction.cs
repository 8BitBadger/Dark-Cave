﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "PluggableAI/Actions/Long Range Attack")]
public class LongRangeAttackAction : Action
{
    public bool projectileFollowTarget;
    public float prijectileLife;
    public GameObject projectile;

    public override void Act(StateController controller)
    {
        //TODO: find a better way to remove or reduce angular drag, angular drag due to the player bumping into the ai
        if (controller.rb2d.angularVelocity > 0)
        {
            controller.rb2d.angularVelocity = 0;
        }
        Attack(controller);
    }

    private void Attack(StateController controller)
    {
        if ((Time.time - controller.timeSinceLastAttack) > controller.stats.attackInterval)
        {
            GameObject tempProjectile = Instantiate(projectile, controller.transform.position, Quaternion.identity);

            Physics2D.IgnoreCollision(tempProjectile.GetComponent<Rigidbody2D>().GetComponent<Collider2D>(), controller.GetComponent<Collider2D>());

               tempProjectile.GetComponent<ProjectileMovement>().ProjectileLife = prijectileLife;
                tempProjectile.GetComponent<ProjectileMovement>().FollowTarget = projectileFollowTarget;
                tempProjectile.GetComponent<ProjectileMovement>().FollowTarget = projectileFollowTarget;

            if (!projectileFollowTarget)
            {
                tempProjectile.GetComponent<ProjectileMovement>().FollowTarget = projectileFollowTarget;
                tempProjectile.GetComponent<ProjectileMovement>().Target = controller.chaseTarget.transform;
 

            }
            else
            {
                //tempProjectile.GetComponent<ProjectileFollowTarget>().
            }
            controller.timeSinceLastAttack = Time.time;
        }
    }
}